
import path from 'path';
import dotenv from 'dotenv';
import express from 'express';
import session from 'express-session';
import mysql from 'mysql2/promise';
import bcrypt from 'bcrypt';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { SESv2Client, SendEmailCommand, GetAccountCommand } from '@aws-sdk/client-sesv2';

/* ---------- ESM __dirname ---------- */
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);
const BASE_URL = process.env.APP_BASE_URL || 'http://localhost:3000';

function sha256Hex(s) {
  return crypto.createHash('sha256').update(s).digest('hex');
}
/* ---------- ENV ---------- */
dotenv.config({ path: path.resolve(__dirname, '.env'), override: true });

/* ---------- APP & MIDDLEWARE ---------- */
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax' }
}));

/* ---------- STATIC ---------- */
app.use(express.static(path.join(__dirname, 'public')));

/* ---------- UPLOADS (static + multer) ---------- */
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
app.use('/uploads', express.static(uploadsDir));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '');
    cb(null, `${Date.now()}_${base}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype && file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('이미지 파일만 업로드 가능합니다.'));
  }
});

/* ---------- DB POOL ---------- */
const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'appuser',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'homespot',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

/* ---------- DB PING (Top-level await in ESM) ---------- */
try {
  const [r] = await pool.query('SELECT 1');
  console.log('[DB] ping ok:', r[0]);
} catch (e) {
  console.error('[DB] ping failed:', e.message);
}

/* ---------- AWS Credentials (conditional session token) ---------- */
const keyId = process.env.AWS_ACCESS_KEY_ID || '';
const hasToken = !!process.env.AWS_SESSION_TOKEN;
const isTempKey = keyId.startsWith('ASIA'); // temporary creds start with ASIA, permanent with AKIA
const creds = isTempKey && hasToken
  ? { accessKeyId: keyId, secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '', sessionToken: process.env.AWS_SESSION_TOKEN }
  : { accessKeyId: keyId, secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '' };

console.log('[AWS ENV]', {
  region: process.env.AWS_REGION || 'ap-northeast-2',
  key_prefix: keyId ? keyId.slice(0,4) : null,
  key_len: keyId.length,
  using_session_token: isTempKey && hasToken
});

/* ---------- SES Client ---------- */
const ses = new SESv2Client({
  region: process.env.AWS_REGION || 'ap-northeast-2',
  credentials: creds
});

/* ---------- ROUTES ---------- */
app.get('/', (req, res) => res.redirect('/login.html'));

/* -- 회원가입(세입자) -- */
app.post('/signup', async (req, res) => {
  try {
    const { username, email, password,nickname, confirmPassword } = req.body;
    if (password !== confirmPassword) {
      return res.send("<script>alert('비밀번호가 일치하지 않습니다');history.back();</script>");
    }
    const [userCheck] = await pool.query("SELECT 1 FROM users WHERE user_name=? LIMIT 1", [username]);
    if (userCheck.length) {
      return res.send("<script>alert('이미 존재하는 아이디입니다');history.back();</script>");
    }
    const [emailCheck] = await pool.query("SELECT 1 FROM users WHERE email=? LIMIT 1", [email]);
    if (emailCheck.length) {
      return res.send("<script>alert('이미 존재하는 이메일입니다');history.back();</script>");
    }
    const hash = await bcrypt.hash(password, 12);
    await pool.query("INSERT INTO users (email, password, user_name, nickname) VALUES (?, ?, ?, ?)", [email, hash, username, nickname]);
    res.send("<script>alert('회원가입 성공! 로그인 해주세요.');location.href='/login.html';</script>");
  } catch (err) {
    console.error('Signup error:', err.message);
    res.send("<script>alert('회원가입 실패');history.back();</script>");
  }
});

/* -- 로그인(관리자/중개사/세입자) -- */
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // 관리자
    {
      const [rows] = await pool.query(
        "SELECT admin_id, username, password FROM admins WHERE username=? LIMIT 1",
        [username]
      );
      if (rows.length) {
        const admin = rows[0];
        const isHash = typeof admin.password === 'string' && admin.password.startsWith('$2');
        const ok = isHash ? await bcrypt.compare(password, admin.password) : (password === admin.password);
        if (!ok) return res.send("<script>alert('비밀번호가 올바르지 않습니다');history.back();</script>");
        req.session.user = { role: 'admin', id: admin.admin_id, username: admin.username };
        return res.redirect('/admin');
      }
    }

    // 중개사(승인 필요)
    {
      const [rows] = await pool.query(
        "SELECT agent_pk_id AS agent_id, email, agent_name AS name, password, license_status FROM agents WHERE email=? OR agent_name=? LIMIT 1",
        [username, username]
      );
      if (rows.length) {
        const a = rows[0];
        if (a.license_status !== 'approved') {
          return res.send("<script>alert('관리자 승인 대기 중입니다');history.back();</script>");
        }
        const ok = await bcrypt.compare(password, a.password);
        if (!ok) return res.send("<script>alert('비밀번호가 올바르지 않습니다');history.back();</script>");
        req.session.user = { role: 'agent', id: a.agent_id, email: a.email, name: a.name };
        return res.redirect('/agent');
      }
    }

    // 세입자
    {
      const [rows] = await pool.query(
        "SELECT user_pk_id AS user_id, email, user_name AS name, password FROM users WHERE email=? OR user_name=? LIMIT 1",
        [username, username]
      );
      if (!rows.length) {
        return res.send("<script>alert('사용자를 찾을 수 없습니다');history.back();</script>");
      }
      const u = rows[0];
      const ok = await bcrypt.compare(password, u.password);
      if (!ok) return res.send("<script>alert('비밀번호가 올바르지 않습니다');history.back();</script>");
      req.session.user = { role: 'tenant', id: u.user_id, email: u.email, name: u.name };
      return res.redirect('/tenant');
    }
  } catch (err) {
    console.error('Login error:', err.message);
    res.send("<script>alert('로그인 실패');history.back();</script>");
  }
});

/* -- 대시보드 -- */
app.get('/admin', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'admin') return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public', 'Admin.html'));
});
app.get('/agent', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'agent') return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public', 'mainpageagent.html'));
});
app.get('/tenant', (req, res) => {
  if (!req.session.user || req.session.user.role !== 'tenant') return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public', 'mainpagetenant.html'));
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login.html'));
});

/* -- 중개사 회원가입(대기 저장) -- */
app.post('/broker-signup', upload.single('license'), async (req, res) => {
  try {
    const name = req.body.name || req.body.username; // 프론트 호환
    const { email, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
      return res.send("<script>alert('비밀번호가 일치하지 않습니다');history.back();</script>");
    }
    const [userCheck] = await pool.query("SELECT 1 FROM agents WHERE agent_name=? LIMIT 1", [name]);
    if (userCheck.length) {
      return res.send("<script>alert('이미 존재하는 아이디입니다');history.back();</script>");
    }
    const [emailCheck] = await pool.query("SELECT 1 FROM agents WHERE email=? LIMIT 1", [email]);
    if (emailCheck.length) {
      return res.send("<script>alert('이미 존재하는 이메일입니다');history.back();</script>");
    }

    const hash = await bcrypt.hash(password, 12);
    const licenseFile = req.file ? req.file.filename : null; // 파일명만 저장
    await pool.query(
      "INSERT INTO agents (email, password, agent_name, nickname, license_url, license_status) VALUES (?, ?, ?, ?, ?, ?)",
      [email, hash, name, nickname, licenseFile, 'pending']
    );

    res.send("<script>alert('회원가입 요청이 접수되었습니다. 관리자 승인을 기다려주세요.');location.href='/login.html';</script>");
  } catch (err) {
    console.error('Broker signup error:', err.message);
    res.send("<script>alert('회원가입 실패');history.back();</script>");
  }
});

/* -- 승인/거절 & 목록 API -- */
app.post('/approve-broker/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query("SELECT email FROM agents WHERE agent_pk_id=?", [id]);
    if (!rows.length) return res.status(404).send('중개사를 찾을 수 없습니다.');

    await pool.query("UPDATE agents SET license_status='approved' WHERE agent_pk_id=?", [id]);
    await sendEmail({ to: rows[0].email, subject: '승인 완료', text: '중개사 회원가입 요청이 승인되었습니다.' });
    res.status(200).send('승인 완료');
  } catch (err) {
    console.error('Approve error:', err.message);
    res.status(500).send('승인 실패');
  }
});

app.post('/reject-broker/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query("SELECT email FROM agents WHERE agent_pk_id=?", [id]);
    if (!rows.length) return res.status(404).send('중개사를 찾을 수 없습니다.');

    await pool.query("UPDATE agents SET license_status='rejected' WHERE agent_pk_id=?", [id]);
    await sendEmail({ to: rows[0].email, subject: '거절 안내', text: '중개사 회원가입 요청이 거절되었습니다.' });
    res.status(200).send('거절 완료');
  } catch (err) {
    console.error('Reject error:', err.message);
    res.status(500).send('거절 실패');
  }
});

app.get('/admin/broker-requests', async (req, res) => {
  try {
    if (!req.session.user || req.session.user.role !== 'admin') {
      return res.status(403).send('관리자 권한이 필요합니다.');
    }
    const [rows] = await pool.query(
      "SELECT agent_pk_id AS agent_id, agent_name AS name, email, license_url, license_status FROM agents WHERE license_status='pending'"
    );
    res.json(rows);
  } catch (err) {
    console.error('List error:', err.message);
    res.status(500).send('서버 오류');
  }
});

/* -- Diagnostics: SES GetAccount -- */
app.get('/__ses_account', async (req, res) => {
  try {
    const out = await ses.send(new GetAccountCommand({}));
    res.json({ ok: true, dedicatedIpAutoWarmupEnabled: out.DedicatedIpAutoWarmupEnabled ?? null, enforcementStatus: out.EnforcementStatus ?? null });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// -- 아이디 찾기 API --
app.post('/find-id', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.send("<script>alert('이메일을 입력해주세요');history.back();</script>");

    // users, agents 양쪽에서 조회 (로그인 아이디는 name 컬럼을 사용 중)
    const [uRows] = await pool.query("SELECT user_name AS name FROM users WHERE email=?", [email]);
    const [aRows] = await pool.query("SELECT agent_name AS name FROM agents WHERE email=?", [email]);

    // 메일 본문 구성
    const lines = [];
    if (uRows.length) lines.push(`세입자(tenant) 아이디: ${uRows.map(r=>r.name).join(', ')}`);
    if (aRows.length) lines.push(`중개사(agent) 아이디: ${aRows.map(r=>r.name).join(', ')}`);

    // 존재 여부와 관계없이 동일 응답(계정 유추 방지). 존재하면 메일 발송
    if (lines.length) {
      await sendEmail({
        to: email,
        subject: '[홈스팟] 아이디 안내',
        text: `요청하신 아이디입니다.\n\n${lines.join('\n')}\n\n만약 본인이 아니라면 이 메일을 무시하세요.`
      });
    }
    return res.send("<script>alert('입력하신 이메일로 안내를 보냈습니다(존재하는 경우)');location.href='/login.html';</script>");
  } catch (err) {
    console.error('find-id error:', err.message);
    return res.send("<script>alert('처리 중 오류가 발생했습니다');history.back();</script>");
  }
});

// -- 비밀번호 재설정 요청 API --
app.post('/find-pwd', async (req, res) => {
  try {
    const { email, userid } = req.body; // userid = 아이디(name)
    if (!email || !userid) {
      return res.send("<script>alert('아이디와 이메일을 모두 입력해주세요');history.back();</script>");
    }

    let userType = null;
    let userId = null;

    // users 우선
    {
      const [rows] = await pool.query(
        "SELECT user_pk_id AS id FROM users WHERE email=? AND user_name=? LIMIT 1",
        [email, userid]
      );
      if (rows.length) {
        userType = 'tenant';
        userId = rows[0].id;
      }
    }

    // 없으면 agents
    if (!userId) {
      const [rows] = await pool.query(
        "SELECT agent_pk_id AS id FROM agents WHERE email=? AND agent_name=? LIMIT 1",
        [email, userid]
      );
      if (rows.length) {
        userType = 'agent';
        userId = rows[0].id;
      }
    }

    // 계정 유무와 관계없이 같은 응답(유출 방지)
    if (userId) {
      const token = crypto.randomBytes(32).toString('hex');
      const tokenHash = sha256Hex(token);
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1시간

      await pool.query(
        "INSERT INTO password_resets (user_type, user_id, email, token_hash, expires_at) VALUES (?, ?, ?, ?, ?)",
        [userType, userId, email, tokenHash, expiresAt]
      );

      const link = `${BASE_URL}/reset-password?token=${token}`;
      await sendEmail({
        to: email,
        subject: '[홈스팟] 비밀번호 재설정 링크',
        text: `아래 링크에서 1시간 이내에 새 비밀번호를 설정하세요:\n${link}\n\n본인이 요청하지 않았다면 무시하세요.`
      });
    }

    return res.send("<script>alert('입력하신 정보와 일치하는 계정이 존재하는 경우, 재설정 링크를 이메일로 보냈습니다');location.href='/login.html';</script>");
  } catch (err) {
    console.error('find-pwd error:', err.message);
    return res.send("<script>alert('처리 중 오류가 발생했습니다');history.back();</script>");
  }
});
app.get("/reset-password", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "reset_password.html"));
});
// 비밀번호 재설정 적용
app.post('/reset-password', async (req, res) => {
  try {
    const { token, password, confirmPassword } = req.body;
    if (!token) return res.send("<script>alert('토큰이 없습니다');history.back();</script>");
    if (!password || password !== confirmPassword) {
      return res.send("<script>alert('비밀번호가 일치하지 않습니다');history.back();</script>");
    }

    const tokenHash = sha256Hex(token);
    const [rows] = await pool.query(
      "SELECT id, user_type, user_id, expires_at, used FROM password_resets WHERE token_hash=? LIMIT 1",
      [tokenHash]
    );
    if (!rows.length) return res.send("<script>alert('유효하지 않은 링크입니다');location.href='/login.html';</script>");

    const r = rows[0];
    if (r.used) return res.send("<script>alert('이미 사용된 링크입니다');location.href='/login.html';</script>");
    if (new Date(r.expires_at) < new Date()) {
      return res.send("<script>alert('링크가 만료되었습니다');location.href='/login.html';</script>");
    }

    // 비밀번호 해시 후 덮어쓰기
    const hash = await bcrypt.hash(password, 12);
    if (r.user_type === 'tenant') {
      await pool.query("UPDATE users SET password=? WHERE user_pk_id=?", [hash, r.user_id]);
    } else {
      await pool.query("UPDATE agents SET password=? WHERE agent_pk_id=?", [hash, r.user_id]);
    }

    // 토큰 사용 처리 및 같은 이메일의 다른 미사용 토큰 무효화(선택)
    await pool.query("UPDATE password_resets SET used=1, used_at=NOW() WHERE id=?", [r.id]);

    res.send("<script>alert('비밀번호가 변경되었습니다. 로그인 해주세요.');location.href='/login.html';</script>");
  } catch (err) {
    console.error('reset-password error:', err.message);
    return res.send("<script>alert('처리 중 오류가 발생했습니다');history.back();</script>");
  }
});

// 프로필페이지
app.get('/profile', (req, res) => {
  if (!req.session.user) return res.redirect('/login.html');
  res.sendFile(path.join(__dirname, 'public', 'profile_setting.html'));
});

//현재 유저 조회 api
app.get('/api/me', async (req, res) => {
  try {
    if (!req.session.user) return res.status(401).json({ ok:false, message:'unauthorized' });
    const u = req.session.user;

    if (u.role === 'agent') {
      const [rows] = await pool.query(
        "SELECT agent_pk_id AS id, agent_name AS username, email, nickname, profile_url FROM agents WHERE agent_pk_id=? LIMIT 1",
        [u.id]
      );
      if (!rows.length) return res.status(404).json({ ok:false });
      return res.json({ ok:true, role:'agent', ...rows[0] });
    } else {
      const [rows] = await pool.query(
        "SELECT user_pk_id AS id, user_name AS username, email, nickname, profile_url FROM users WHERE user_pk_id=? LIMIT 1",
        [u.id]
      );
      if (!rows.length) return res.status(404).json({ ok:false });
      return res.json({ ok:true, role:'tenant', ...rows[0] });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false });
  }
});

//닉네임 저장 api
app.post('/api/profile/nickname', async (req, res) => {
  try {
    if (!req.session.user) return res.status(401).json({ ok:false });
    const { nickname } = req.body;
    if (!nickname || nickname.length > 64) {
      return res.status(400).json({ ok:false, message:'닉네임 길이 확인' });
    }

    const u = req.session.user;
    if (u.role === 'agent') {
      await pool.query("UPDATE agents SET nickname=? WHERE agent_pk_id=?", [nickname, u.id]);
    } else {
      await pool.query("UPDATE users SET nickname=? WHERE user_pk_id=?", [nickname, u.id]);
    }
    res.json({ ok:true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false });
  }
});

//프로필사진 설정
app.post('/api/profile/photo', upload.single('photo'), async (req, res) => {
  try {
    if (!req.session.user) return res.status(401).json({ ok:false });
    if (!req.file) return res.status(400).json({ ok:false, message:'파일 없음' });

    const filename = req.file.filename; // /uploads/{filename} 로 정적 제공 중
    const u = req.session.user;

    if (u.role === 'agent') {
      await pool.query("UPDATE agents SET profile_url=? WHERE agent_pk_id=?", [filename, u.id]);
    } else {
      await pool.query("UPDATE users SET profile_url=? WHERE user_pk_id=?", [filename, u.id]);
    }
    res.json({ ok:true, url: filename });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false, message:'업로드 실패' });
  }
});

//회원 탈퇴
app.post('/api/profile/delete', async (req, res) => {
  try {
    if (!req.session.user) return res.status(401).json({ ok:false });
    const { confirm } = req.body;
    if (confirm !== '탈퇴합니다') return res.status(400).json({ ok:false, message:'확인 문구 불일치' });

    const u = req.session.user;
    if (u.role === 'agent') {
      await pool.query("DELETE FROM agents WHERE agent_pk_id=?", [u.id]);
    } else {
      await pool.query("DELETE FROM users WHERE user_pk_id=?", [u.id]);
    }
    req.session.destroy(() => {});
    res.json({ ok:true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok:false });
  }
});


/* ---------- START SERVER ---------- */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server running at http://localhost:" + PORT));

/* ---------- SES SDK MAILER ---------- */
async function sendEmail({ to, subject, text, html }) {
  const input = {
    FromEmailAddress: process.env.SES_FROM, // SES에서 검증된 이메일
    Destination: { ToAddresses: Array.isArray(to) ? to : [to] },
    Content: {
      Simple: {
        Subject: { Data: subject, Charset: 'UTF-8' },
        Body: {
          Text: text ? { Data: text, Charset: 'UTF-8' } : undefined,
          Html: html ? { Data: html, Charset: 'UTF-8' } : undefined
        }
      }
    }
    // 필요 시 ConfigurationSetName 추가 가능
  };
  await ses.send(new SendEmailCommand(input));
}
